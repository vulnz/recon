import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class NetScanner {
    static ConcurrentHashMap<String, CopyOnWriteArrayList<PortResult>> results = new ConcurrentHashMap<>();
    static int timeout = 200;
    static int threads = 20;
    static boolean grabBanners = true;
    static boolean verbose = false;

    public static void main(String[] args) {
        if (args.length < 1) {
            printUsage();
            return;
        }

        String target = args[0];
        int startPort = -1;
        int endPort = -1;
        String outputFile = null;
        boolean noAuthOnly = false;

        // Parse arguments
        try {
            for (int i = 1; i < args.length; i++) {
                if (args[i].equals("-p") && i + 1 < args.length) {
                    String[] portRange = args[++i].split("-");
                    startPort = Integer.parseInt(portRange[0]);
                    endPort = portRange.length > 1 ? Integer.parseInt(portRange[1]) : startPort;
                } else if (args[i].equals("-t") && i + 1 < args.length) {
                    threads = Integer.parseInt(args[++i]);
                } else if (args[i].equals("-o") && i + 1 < args.length) {
                    outputFile = args[++i];
                } else if (args[i].equals("--timeout") && i + 1 < args.length) {
                    timeout = Integer.parseInt(args[++i]);
                } else if (args[i].equals("--no-banner")) {
                    grabBanners = false;
                } else if (args[i].equals("--noauth")) {
                    noAuthOnly = true;
                } else if (args[i].equals("-v") || args[i].equals("--verbose")) {
                    verbose = true;
                }
            }
        } catch (Exception e) {
            System.out.println("Error parsing arguments: " + e.getMessage());
            printUsage();
            return;
        }

        // Determine ports to scan
        int[] ports;
        if (noAuthOnly) {
            ports = getNoAuthPorts();
            System.out.println("[!] Scanning for services often without authentication");
        } else if (startPort > 0) {
            if (endPort < startPort) {
                endPort = startPort;
            }
            ports = new int[endPort - startPort + 1];
            for (int i = 0; i < ports.length; i++) {
                ports[i] = startPort + i;
            }
        } else {
            ports = getCommonPorts();
        }

        // Parse target IPs
        List<String> ips = parseTarget(target);
        if (ips.isEmpty()) {
            System.out.println("Error: No valid IP addresses found for target: " + target);
            return;
        }

        System.out.println("");
        System.out.println("NetScanner - Java Network Scanner");
        System.out.println("==================================");
        System.out.println("Targets: " + ips.size() + " host(s)");
        System.out.println("Ports: " + ports.length + " port(s)");
        System.out.println("Threads: " + threads);
        System.out.println("Timeout: " + timeout + "ms");
        System.out.println("Banner grabbing: " + (grabBanners ? "enabled" : "disabled"));
        System.out.println("==================================");
        System.out.println("");

        long startTime = System.currentTimeMillis();

        // Create thread pool
        ExecutorService executor = Executors.newFixedThreadPool(threads);
        List<Future<?>> futures = new ArrayList<>();

        // Submit scan tasks
        for (final String ip : ips) {
            for (final int port : ports) {
                Future<?> future = executor.submit(new Runnable() {
                    @Override
                    public void run() {
                        scanPort(ip, port);
                    }
                });
                futures.add(future);
            }
        }

        // Wait for all tasks to complete
        for (Future<?> future : futures) {
            try {
                future.get(timeout * 3, TimeUnit.MILLISECONDS);
            } catch (TimeoutException e) {
                future.cancel(true);
            } catch (Exception e) {
                // Ignore
            }
        }

        executor.shutdownNow();
        try {
            executor.awaitTermination(5, TimeUnit.SECONDS);
        } catch (Exception e) {}

        long endTime = System.currentTimeMillis();

        // Print and save results
        printResults();

        if (outputFile != null) {
            saveReport(outputFile);
        }

        System.out.println("");
        System.out.println("Scan completed in " + (endTime - startTime) / 1000.0 + " seconds");
    }

    static void printUsage() {
        System.out.println("NetScanner - Java Network Scanner with Service Detection");
        System.out.println("=========================================================");
        System.out.println("");
        System.out.println("Usage: java NetScanner <target> [options]");
        System.out.println("");
        System.out.println("Target formats:");
        System.out.println("  192.168.1.1          Single IP");
        System.out.println("  192.168.1.1-50       IP range");
        System.out.println("  192.168.1.0/24       Subnet (CIDR)");
        System.out.println("");
        System.out.println("Options:");
        System.out.println("  -p 1-1000            Port range (default: common ports)");
        System.out.println("  -t 20                Threads (default: 20)");
        System.out.println("  -o report.txt        Output file");
        System.out.println("  --timeout 200        Timeout in ms (default: 200)");
        System.out.println("  --no-banner          Skip banner grabbing");
        System.out.println("  --noauth             Only scan services often without auth");
        System.out.println("  -v, --verbose        Verbose output");
        System.out.println("");
        System.out.println("Examples:");
        System.out.println("  java NetScanner 192.168.1.0/24");
        System.out.println("  java NetScanner 192.168.1.1-254 -p 1-1000 -t 50 -o scan.txt");
        System.out.println("  java NetScanner 10.0.0.0/24 --noauth -o noauth_services.txt");
    }

    static void scanPort(String ip, int port) {
        Socket socket = null;
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ip, port), timeout);
            
            String banner = "";
            String authStatus = "";
            
            if (grabBanners) {
                try {
                    BannerResult br = grabBanner(socket, ip, port);
                    banner = br.banner;
                    authStatus = br.authStatus;
                } catch (Exception e) {
                    if (verbose) {
                        System.out.println("[DEBUG] Banner grab failed for " + ip + ":" + port + " - " + e.getMessage());
                    }
                }
            }

            PortResult pr = new PortResult(port, getService(port), banner, authStatus);
            CopyOnWriteArrayList<PortResult> portList = results.get(ip);
            if (portList == null) {
                portList = new CopyOnWriteArrayList<>();
                CopyOnWriteArrayList<PortResult> existing = results.putIfAbsent(ip, portList);
                if (existing != null) {
                    portList = existing;
                }
            }
            portList.add(pr);
            
            String output = "[+] " + ip + ":" + port + " OPEN (" + getService(port) + ")";
            if (!banner.isEmpty()) {
                output += " - " + banner;
            }
            if (!authStatus.isEmpty()) {
                output += " [" + authStatus + "]";
            }
            System.out.println(output);
        } catch (Exception e) {
            if (verbose) {
                System.out.println("[-] " + ip + ":" + port + " closed/filtered");
            }
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception e) {}
            }
        }
    }

    static BannerResult grabBanner(Socket socket, String ip, int port) {
        String banner = "";
        String authStatus = "";
        
        try {
            socket.setSoTimeout(timeout * 2);
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();

            switch (port) {
                case 9200: // Elasticsearch
                case 9201:
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("cluster_name") || banner.contains("lucene_version")) {
                        authStatus = "NO AUTH - Elasticsearch exposed!";
                    } else if (banner.contains("401") || banner.contains("security")) {
                        authStatus = "Auth enabled";
                    }
                    break;

                case 5984: // CouchDB
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("couchdb") || banner.contains("Welcome")) {
                        authStatus = "NO AUTH - CouchDB exposed!";
                    }
                    break;

                case 2181: // ZooKeeper
                    out.write("stat\n".getBytes());
                    out.flush();
                    banner = readResponse(in);
                    if (banner.contains("Zookeeper") || banner.contains("Clients") || banner.contains("version")) {
                        authStatus = "NO AUTH - ZooKeeper exposed!";
                    }
                    break;

                case 6379: // Redis
                    out.write("INFO\r\n".getBytes());
                    out.flush();
                    banner = readResponse(in);
                    if (banner.contains("redis_version")) {
                        authStatus = "NO AUTH - Redis exposed!";
                    } else if (banner.contains("NOAUTH") || banner.contains("Authentication")) {
                        authStatus = "Auth required";
                    }
                    break;

                case 27017: // MongoDB
                case 27018:
                    banner = "MongoDB";
                    authStatus = "Check manually";
                    break;

                case 28017: // MongoDB HTTP
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("MongoDB") || banner.contains("serverStatus")) {
                        authStatus = "NO AUTH - MongoDB HTTP exposed!";
                    }
                    break;

                case 11211: // Memcached
                    out.write("stats\r\n".getBytes());
                    out.flush();
                    banner = readResponse(in);
                    if (banner.contains("STAT") || banner.contains("pid") || banner.contains("version")) {
                        authStatus = "NO AUTH - Memcached exposed!";
                    }
                    break;

                case 5601: // Kibana
                    banner = httpGet(ip, port, "/api/status");
                    if (banner.contains("available") || banner.contains("kibana") || banner.contains("version")) {
                        authStatus = "NO AUTH - Kibana exposed!";
                    } else if (banner.contains("401")) {
                        authStatus = "Auth enabled";
                    }
                    break;

                case 9042: // Cassandra
                case 9160:
                    banner = "Cassandra";
                    authStatus = "Check manually";
                    break;

                case 8500: // Consul
                    banner = httpGet(ip, port, "/v1/agent/self");
                    if (banner.contains("Config") || banner.contains("Member") || banner.contains("DebugConfig")) {
                        authStatus = "NO AUTH - Consul exposed!";
                    }
                    break;

                case 2379: // etcd
                case 2380:
                    banner = httpGet(ip, port, "/version");
                    if (banner.contains("etcdserver") || banner.contains("etcdcluster")) {
                        authStatus = "NO AUTH - etcd exposed!";
                    }
                    break;

                case 2375: // Docker API (unencrypted)
                    banner = httpGet(ip, port, "/version");
                    if (banner.contains("ApiVersion") || banner.contains("Version") || banner.contains("Os")) {
                        authStatus = "CRITICAL - Docker API NO AUTH!";
                    }
                    break;

                case 2376: // Docker API (TLS)
                    banner = "Docker TLS";
                    authStatus = "TLS enabled - check certs";
                    break;

                case 50070: // Hadoop NameNode
                case 50075:
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("Hadoop") || banner.contains("NameNode") || banner.contains("dfs")) {
                        authStatus = "NO AUTH - Hadoop exposed!";
                    }
                    break;

                case 50090: // Hadoop Secondary NN
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("Hadoop") || banner.contains("Secondary")) {
                        authStatus = "NO AUTH - Hadoop Secondary exposed!";
                    }
                    break;

                case 8088: // Hadoop YARN
                    banner = httpGet(ip, port, "/cluster");
                    if (banner.contains("hadoop") || banner.contains("ResourceManager") || banner.contains("cluster")) {
                        authStatus = "NO AUTH - Hadoop YARN exposed!";
                    }
                    break;

                case 10000: // Hive
                    banner = "Hive Server";
                    authStatus = "Check manually";
                    break;

                case 9000: // ClickHouse / HDFS
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("ClickHouse") || banner.contains("Ok")) {
                        authStatus = "Possible NO AUTH";
                    }
                    break;

                case 8086: // InfluxDB
                    banner = httpGet(ip, port, "/ping");
                    if (!banner.contains("401") && !banner.contains("Unauthorized")) {
                        authStatus = "NO AUTH - InfluxDB exposed!";
                    } else {
                        authStatus = "Auth enabled";
                    }
                    break;

                case 3000: // Grafana
                    banner = httpGet(ip, port, "/api/health");
                    if (banner.contains("ok") || banner.contains("database") || banner.contains("commit")) {
                        authStatus = "Check default creds admin:admin";
                    }
                    break;

                case 15672: // RabbitMQ Management
                    banner = httpGet(ip, port, "/api/whoami");
                    if (banner.contains("401") || banner.contains("Unauthorized")) {
                        authStatus = "Auth enabled - try guest:guest";
                    } else if (banner.contains("name") || banner.contains("tags")) {
                        authStatus = "NO AUTH - RabbitMQ exposed!";
                    }
                    break;

                case 4444: // ArangoDB / Selenium
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("arango") || banner.contains("ArangoDB")) {
                        authStatus = "Check auth settings";
                    } else if (banner.contains("WebDriver") || banner.contains("selenium")) {
                        authStatus = "Selenium Grid - NO AUTH";
                    }
                    break;

                case 7474: // Neo4j
                    banner = httpGet(ip, port, "/");
                    if (banner.contains("neo4j") || banner.contains("data") || banner.contains("management")) {
                        authStatus = "Check default creds neo4j:neo4j";
                    }
                    break;

                case 5000: // Docker Registry
                    banner = httpGet(ip, port, "/v2/");
                    if (banner.contains("{}") || banner.contains("200 OK")) {
                        authStatus = "NO AUTH - Docker Registry exposed!";
                    } else if (banner.contains("401")) {
                        authStatus = "Auth enabled";
                    }
                    break;

                case 6443: // Kubernetes API
                    banner = httpGet(ip, port, "/version");
                    if (banner.contains("major") || banner.contains("gitVersion") || banner.contains("platform")) {
                        authStatus = "Kubernetes API accessible";
                    }
                    break;

                case 10250: // Kubelet
                case 10255:
                    banner = httpGet(ip, port, "/pods");
                    if (banner.contains("items") || banner.contains("metadata") || banner.contains("spec")) {
                        authStatus = "NO AUTH - Kubelet exposed!";
                    } else if (banner.contains("401") || banner.contains("403")) {
                        authStatus = "Auth enabled";
                    }
                    break;

                case 8080:
                case 8081:
                case 80:
                case 443:
                case 8443:
                    banner = httpGet(ip, port, "/");
                    banner = truncate(banner, 60);
                    break;

                case 21: // FTP
                    banner = readResponse(in);
                    if (banner.toLowerCase().contains("anonymous")) {
                        authStatus = "Anonymous FTP allowed!";
                    }
                    banner = truncate(banner, 60);
                    break;

                case 22: // SSH
                    banner = readResponse(in);
                    banner = truncate(banner, 60);
                    break;

                case 23: // Telnet
                    banner = readResponse(in);
                    banner = truncate(banner, 60);
                    break;

                case 389: // LDAP
                case 636:
                case 3268:
                case 3269:
                    banner = "LDAP";
                    authStatus = "Check anonymous bind";
                    break;

                case 1433: // MSSQL
                    banner = "MSSQL";
                    break;

                case 3306: // MySQL
                    banner = readResponse(in);
                    if (banner.toLowerCase().contains("mysql") || banner.toLowerCase().contains("mariadb")) {
                        banner = "MySQL/MariaDB";
                    } else {
                        banner = truncate(banner, 60);
                    }
                    break;

                case 5432: // PostgreSQL
                    banner = "PostgreSQL";
                    break;

                case 1521: // Oracle
                    banner = "Oracle";
                    break;

                case 5672: // RabbitMQ AMQP
                    banner = "RabbitMQ AMQP";
                    authStatus = "Check guest:guest";
                    break;

                case 9092: // Kafka
                    banner = "Kafka";
                    authStatus = "Check manually";
                    break;

                case 8983: // Solr
                    banner = httpGet(ip, port, "/solr/admin/info/system");
                    if (banner.contains("solr") || banner.contains("lucene")) {
                        authStatus = "NO AUTH - Solr exposed!";
                    }
                    break;

                case 7199: // Cassandra JMX
                    banner = "Cassandra JMX";
                    authStatus = "Check manually";
                    break;

                case 9999: // JMX
                case 1099:
                    banner = "JMX";
                    authStatus = "Check for unauthenticated JMX";
                    break;

                default:
                    try {
                        byte[] buffer = new byte[512];
                        socket.setSoTimeout(timeout);
                        int len = in.read(buffer);
                        if (len > 0) {
                            banner = new String(buffer, 0, len).trim();
                            banner = truncate(cleanBanner(banner), 60);
                        }
                    } catch (Exception e) {}
                    break;
            }
        } catch (Exception e) {
            if (verbose) {
                System.out.println("[DEBUG] Error grabbing banner: " + e.getMessage());
            }
        }

        // Clean up banner
        banner = cleanBanner(banner);
        banner = truncate(banner, 80);

        return new BannerResult(banner, authStatus);
    }

    static String truncate(String s, int maxLen) {
        if (s == null) return "";
        if (s.length() <= maxLen) return s;
        return s.substring(0, maxLen) + "...";
    }

    static String cleanBanner(String banner) {
        if (banner == null) return "";
        return banner.replaceAll("[\\r\\n\\t]+", " ")
                     .replaceAll("[^\\x20-\\x7E]", "")
                     .trim();
    }

    static String httpGet(String host, int port, String path) {
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress(host, port), timeout);
            s.setSoTimeout(timeout * 2);

            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

            out.print("GET " + path + " HTTP/1.0\r\n");
            out.print("Host: " + host + "\r\n");
            out.print("User-Agent: NetScanner/1.0\r\n");
            out.print("Accept: */*\r\n");
            out.print("Connection: close\r\n");
            out.print("\r\n");
            out.flush();

            StringBuilder response = new StringBuilder();
            String line;
            int lines = 0;
            while ((line = in.readLine()) != null && lines < 30) {
                response.append(line).append(" ");
                lines++;
            }

            return response.toString();
        } catch (Exception e) {
            return "";
        } finally {
            if (s != null) {
                try {
                    s.close();
                } catch (Exception e) {}
            }
        }
    }

    static String readResponse(InputStream in) {
        try {
            byte[] buffer = new byte[1024];
            int len = in.read(buffer);
            if (len > 0) {
                return new String(buffer, 0, len).trim();
            }
        } catch (Exception e) {}
        return "";
    }

    static List<String> parseTarget(String target) {
        List<String> ips = new ArrayList<>();

        try {
            if (target.contains("/")) {
                // CIDR notation: 192.168.1.0/24
                String[] parts = target.split("/");
                String baseIP = parts[0];
                int prefix = Integer.parseInt(parts[1]);
                ips = getCIDRAddresses(baseIP, prefix);
            } else if (target.contains("-")) {
                // Range: 192.168.1.1-50 or 192.168.1-2.1-50
                String[] parts = target.split("\\.");
                if (parts.length == 4 && parts[3].contains("-")) {
                    String[] range = parts[3].split("-");
                    int start = Integer.parseInt(range[0]);
                    int end = Integer.parseInt(range[1]);
                    String baseIP = parts[0] + "." + parts[1] + "." + parts[2] + ".";
                    for (int i = start; i <= end; i++) {
                        ips.add(baseIP + i);
                    }
                } else {
                    // Just add as-is if format is unexpected
                    ips.add(target);
                }
            } else {
                // Single IP or hostname
                ips.add(target);
            }
        } catch (Exception e) {
            System.out.println("Warning: Error parsing target '" + target + "': " + e.getMessage());
            ips.add(target);
        }

        return ips;
    }

    static List<String> getCIDRAddresses(String baseIP, int prefix) {
        List<String> ips = new ArrayList<>();
        try {
            String[] parts = baseIP.split("\\.");
            if (parts.length != 4) {
                ips.add(baseIP);
                return ips;
            }
            
            long ip = 0;
            for (int i = 0; i < 4; i++) {
                ip = ip << 8 | Integer.parseInt(parts[i]);
            }

            int hostBits = 32 - prefix;
            long numHosts = (1L << hostBits) - 2;
            long networkAddr = ip & (0xFFFFFFFFL << hostBits);

            // Limit to 65534 hosts max
            long maxHosts = Math.min(numHosts, 65534);
            
            for (long i = 1; i <= maxHosts; i++) {
                long addr = networkAddr + i;
                String ipStr = ((addr >> 24) & 0xFF) + "." +
                               ((addr >> 16) & 0xFF) + "." +
                               ((addr >> 8) & 0xFF) + "." +
                               (addr & 0xFF);
                ips.add(ipStr);
            }
        } catch (Exception e) {
            System.out.println("Warning: Error parsing CIDR: " + e.getMessage());
            ips.add(baseIP);
        }
        return ips;
    }

    static void printResults() {
        System.out.println("");
        System.out.println("==================================");
        System.out.println("SCAN RESULTS");
        System.out.println("==================================");

        // Sort results by IP
        List<String> sortedIPs = new ArrayList<>(results.keySet());
        Collections.sort(sortedIPs, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                try {
                    String[] pa = a.split("\\.");
                    String[] pb = b.split("\\.");
                    for (int i = 0; i < 4 && i < pa.length && i < pb.length; i++) {
                        int cmp = Integer.compare(Integer.parseInt(pa[i]), Integer.parseInt(pb[i]));
                        if (cmp != 0) return cmp;
                    }
                } catch (Exception e) {}
                return a.compareTo(b);
            }
        });

        int noAuthCount = 0;

        for (String ip : sortedIPs) {
            CopyOnWriteArrayList<PortResult> ports = results.get(ip);
            if (ports == null || ports.isEmpty()) continue;

            // Sort ports
            List<PortResult> portList = new ArrayList<>(ports);
            Collections.sort(portList, new Comparator<PortResult>() {
                @Override
                public int compare(PortResult a, PortResult b) {
                    return Integer.compare(a.port, b.port);
                }
            });

            System.out.println("");
            System.out.println("Host: " + ip);
            System.out.println("------------------------");
            for (PortResult pr : portList) {
                String line = "  " + pr.port + "/tcp\topen\t" + pr.service;
                if (pr.banner != null && !pr.banner.isEmpty()) {
                    line += "\t" + pr.banner;
                }
                System.out.println(line);
                if (pr.authStatus != null && !pr.authStatus.isEmpty()) {
                    System.out.println("    [!] " + pr.authStatus);
                    if (pr.authStatus.contains("NO AUTH") || pr.authStatus.contains("CRITICAL")) {
                        noAuthCount++;
                    }
                }
            }
        }

        if (results.isEmpty()) {
            System.out.println("No open ports found.");
        }

        if (noAuthCount > 0) {
            System.out.println("");
            System.out.println("==========================================");
            System.out.println("[!] WARNING: " + noAuthCount + " service(s) found without authentication!");
            System.out.println("==========================================");
        }
    }

    static void saveReport(String filename) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new FileWriter(filename));
            writer.println("NetScanner Security Report");
            writer.println("Generated: " + new java.util.Date());
            writer.println("==========================================");

            // Sort results by IP
            List<String> sortedIPs = new ArrayList<>(results.keySet());
            Collections.sort(sortedIPs, new Comparator<String>() {
                @Override
                public int compare(String a, String b) {
                    try {
                        String[] pa = a.split("\\.");
                        String[] pb = b.split("\\.");
                        for (int i = 0; i < 4 && i < pa.length && i < pb.length; i++) {
                            int cmp = Integer.compare(Integer.parseInt(pa[i]), Integer.parseInt(pb[i]));
                            if (cmp != 0) return cmp;
                        }
                    } catch (Exception e) {}
                    return a.compareTo(b);
                }
            });

            List<String> noAuthFindings = new ArrayList<>();

            for (String ip : sortedIPs) {
                CopyOnWriteArrayList<PortResult> ports = results.get(ip);
                if (ports == null || ports.isEmpty()) continue;

                List<PortResult> portList = new ArrayList<>(ports);
                Collections.sort(portList, new Comparator<PortResult>() {
                    @Override
                    public int compare(PortResult a, PortResult b) {
                        return Integer.compare(a.port, b.port);
                    }
                });

                writer.println("");
                writer.println("Host: " + ip);
                writer.println("Open ports:");
                for (PortResult pr : portList) {
                    String banner = pr.banner != null ? pr.banner : "";
                    writer.println("  " + pr.port + "/tcp\t" + pr.service + "\t" + banner);
                    if (pr.authStatus != null && !pr.authStatus.isEmpty()) {
                        writer.println("    Status: " + pr.authStatus);
                        if (pr.authStatus.contains("NO AUTH") || pr.authStatus.contains("CRITICAL")) {
                            noAuthFindings.add(ip + ":" + pr.port + " - " + pr.service + " - " + pr.authStatus);
                        }
                    }
                }
            }

            if (!noAuthFindings.isEmpty()) {
                writer.println("");
                writer.println("==========================================");
                writer.println("SECURITY FINDINGS - NO AUTHENTICATION");
                writer.println("==========================================");
                for (String finding : noAuthFindings) {
                    writer.println("[CRITICAL] " + finding);
                }
            }

            System.out.println("");
            System.out.println("Report saved to: " + filename);
        } catch (Exception e) {
            System.out.println("Error saving report: " + e.getMessage());
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    static int[] getNoAuthPorts() {
        return new int[] {
            1099,   // JMX RMI
            2181,   // ZooKeeper
            2375,   // Docker API
            2376,   // Docker TLS
            2379,   // etcd
            2380,   // etcd peer
            3000,   // Grafana
            4444,   // ArangoDB/Selenium
            5000,   // Docker Registry
            5601,   // Kibana
            5672,   // RabbitMQ AMQP
            5984,   // CouchDB
            6379,   // Redis
            6443,   // Kubernetes API
            7199,   // Cassandra JMX
            7474,   // Neo4j
            8086,   // InfluxDB
            8088,   // Hadoop YARN
            8500,   // Consul
            8983,   // Solr
            9000,   // ClickHouse/HDFS
            9042,   // Cassandra CQL
            9092,   // Kafka
            9160,   // Cassandra Thrift
            9200,   // Elasticsearch HTTP
            9201,   // Elasticsearch
            9300,   // Elasticsearch Transport
            9999,   // JMX
            10000,  // Hive
            10250,  // Kubelet
            10255,  // Kubelet read-only
            11211,  // Memcached
            15672,  // RabbitMQ Management
            27017,  // MongoDB
            27018,  // MongoDB
            28017,  // MongoDB HTTP
            50070,  // Hadoop NameNode
            50075,  // Hadoop DataNode
            50090,  // Hadoop Secondary NN
        };
    }

    static int[] getCommonPorts() {
        return new int[] {
            21, 22, 23, 25, 53, 80, 88, 110, 111, 135, 139, 143, 161, 162,
            389, 443, 445, 464, 465, 514, 587, 636, 993, 995, 1099,
            1080, 1433, 1434, 1521, 1723, 2049, 2181, 2375, 2376, 2379, 2380,
            3000, 3268, 3269, 3306, 3389, 4443, 4444, 5000, 5060, 5061,
            5432, 5500, 5601, 5672, 5900, 5984, 5985, 5986, 6379, 6443,
            7001, 7002, 7199, 7474, 8000, 8008, 8080, 8081, 8086, 8088, 8443,
            8500, 8888, 8983, 9000, 9042, 9090, 9092, 9160, 9200, 9201, 9300, 9443, 9999,
            10000, 10250, 10255, 11211, 15672, 27017, 27018, 28017,
            50000, 50070, 50075, 50090
        };
    }

    static String getService(int port) {
        switch (port) {
            case 21: return "FTP";
            case 22: return "SSH";
            case 23: return "Telnet";
            case 25: return "SMTP";
            case 53: return "DNS";
            case 80: return "HTTP";
            case 88: return "Kerberos";
            case 110: return "POP3";
            case 111: return "RPC";
            case 135: return "MSRPC";
            case 139: return "NetBIOS-SSN";
            case 143: return "IMAP";
            case 161: return "SNMP";
            case 162: return "SNMP-Trap";
            case 389: return "LDAP";
            case 443: return "HTTPS";
            case 445: return "SMB";
            case 464: return "Kerberos-Change";
            case 465: return "SMTPS";
            case 514: return "Syslog";
            case 587: return "SMTP-Submission";
            case 636: return "LDAPS";
            case 993: return "IMAPS";
            case 995: return "POP3S";
            case 1080: return "SOCKS";
            case 1099: return "JMX-RMI";
            case 1433: return "MSSQL";
            case 1434: return "MSSQL-UDP";
            case 1521: return "Oracle";
            case 1723: return "PPTP";
            case 2049: return "NFS";
            case 2181: return "ZooKeeper";
            case 2375: return "Docker-API";
            case 2376: return "Docker-TLS";
            case 2379: return "etcd";
            case 2380: return "etcd-peer";
            case 3000: return "Grafana";
            case 3268: return "LDAP-GC";
            case 3269: return "LDAPS-GC";
            case 3306: return "MySQL";
            case 3389: return "RDP";
            case 4443: return "HTTPS-Alt";
            case 4444: return "ArangoDB/Selenium";
            case 5000: return "Docker-Registry";
            case 5060: return "SIP";
            case 5061: return "SIP-TLS";
            case 5432: return "PostgreSQL";
            case 5500: return "VNC";
            case 5601: return "Kibana";
            case 5672: return "RabbitMQ-AMQP";
            case 5900: return "VNC";
            case 5984: return "CouchDB";
            case 5985: return "WinRM-HTTP";
            case 5986: return "WinRM-HTTPS";
            case 6379: return "Redis";
            case 6443: return "Kubernetes-API";
            case 7001: return "WebLogic";
            case 7002: return "WebLogic-SSL";
            case 7199: return "Cassandra-JMX";
            case 7474: return "Neo4j";
            case 8000: return "HTTP-Alt";
            case 8008: return "HTTP-Alt";
            case 8080: return "HTTP-Proxy";
            case 8081: return "HTTP-Alt";
            case 8086: return "InfluxDB";
            case 8088: return "Hadoop-YARN";
            case 8443: return "HTTPS-Alt";
            case 8500: return "Consul";
            case 8888: return "HTTP-Alt";
            case 8983: return "Solr";
            case 9000: return "ClickHouse/HDFS";
            case 9042: return "Cassandra-CQL";
            case 9090: return "HTTP-Alt";
            case 9092: return "Kafka";
            case 9160: return "Cassandra-Thrift";
            case 9200: return "Elasticsearch";
            case 9201: return "Elasticsearch";
            case 9300: return "Elasticsearch-Transport";
            case 9443: return "HTTPS-Alt";
            case 9999: return "JMX";
            case 10000: return "Hive";
            case 10250: return "Kubelet";
            case 10255: return "Kubelet-RO";
            case 11211: return "Memcached";
            case 15672: return "RabbitMQ-Mgmt";
            case 27017: return "MongoDB";
            case 27018: return "MongoDB";
            case 28017: return "MongoDB-HTTP";
            case 50000: return "SAP";
            case 50070: return "Hadoop-NameNode";
            case 50075: return "Hadoop-DataNode";
            case 50090: return "Hadoop-SecondaryNN";
            default: return "unknown";
        }
    }

    static class PortResult {
        int port;
        String service;
        String banner;
        String authStatus;

        PortResult(int port, String service, String banner, String authStatus) {
            this.port = port;
            this.service = service;
            this.banner = banner;
            this.authStatus = authStatus;
        }
    }

    static class BannerResult {
        String banner;
        String authStatus;

        BannerResult(String banner, String authStatus) {
            this.banner = banner;
            this.authStatus = authStatus;
        }
    }
}