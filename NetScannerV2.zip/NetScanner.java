import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class NetScanner {
    static ConcurrentHashMap<String, CopyOnWriteArrayList<PortResult>> results = new ConcurrentHashMap<>();
    static ConcurrentHashMap<String, CopyOnWriteArrayList<SmbShareInfo>> smbShares = new ConcurrentHashMap<>();
    static int timeout = 200;
    static int threads = 50;
    static boolean grabBanners = true;
    static boolean verbose = false;
    static boolean scanSmb = true;

    public static void main(String[] args) {
        if (args.length < 1) {
            printUsage();
            return;
        }

        String target = null;
        String inputFile = null;
        int startPort = -1;
        int endPort = -1;
        String outputFile = null;
        boolean noAuthOnly = false;
        boolean fullScan = false;

        try {
            for (int i = 0; i < args.length; i++) {
                if (args[i].equals("-iL") && i + 1 < args.length) {
                    inputFile = args[++i];
                } else if (args[i].equals("-p") && i + 1 < args.length) {
                    String[] portRange = args[++i].split("-");
                    startPort = Integer.parseInt(portRange[0]);
                    endPort = portRange.length > 1 ? Integer.parseInt(portRange[1]) : startPort;
                } else if (args[i].equals("-t") && i + 1 < args.length) {
                    threads = Integer.parseInt(args[++i]);
                } else if (args[i].equals("-o") && i + 1 < args.length) {
                    outputFile = args[++i];
                } else if (args[i].equals("--timeout") && i + 1 < args.length) {
                    timeout = Integer.parseInt(args[++i]);
                } else if (args[i].equals("--no-banner")) {
                    grabBanners = false;
                } else if (args[i].equals("--noauth")) {
                    noAuthOnly = true;
                } else if (args[i].equals("-v") || args[i].equals("--verbose")) {
                    verbose = true;
                } else if (args[i].equals("--full") || args[i].equals("-F")) {
                    fullScan = true;
                } else if (args[i].equals("--no-smb")) {
                    scanSmb = false;
                } else if (!args[i].startsWith("-") && target == null) {
                    target = args[i];
                }
            }
        } catch (Exception e) {
            System.out.println("Error parsing arguments: " + e.getMessage());
            printUsage();
            return;
        }

        if (target == null && inputFile == null) {
            System.out.println("Error: No target specified. Use IP/range or -iL <file>");
            printUsage();
            return;
        }

        List<String> ips = new ArrayList<>();
        
        if (inputFile != null) {
            ips = readTargetsFromFile(inputFile);
            if (ips.isEmpty()) {
                System.out.println("Error: No valid targets found in file: " + inputFile);
                return;
            }
            System.out.println("[*] Loaded " + ips.size() + " target(s) from " + inputFile);
        } else {
            ips = parseTarget(target);
        }

        if (ips.isEmpty()) {
            System.out.println("Error: No valid IP addresses found");
            return;
        }

        int[] ports;
        if (fullScan) {
            System.out.println("[!] Full scan mode: scanning all 65535 ports");
            ports = new int[65535];
            for (int i = 0; i < 65535; i++) {
                ports[i] = i + 1;
            }
        } else if (noAuthOnly) {
            ports = getNoAuthPorts();
            System.out.println("[!] Scanning for unauthenticated services only");
        } else if (startPort > 0) {
            if (endPort < startPort) endPort = startPort;
            ports = new int[endPort - startPort + 1];
            for (int i = 0; i < ports.length; i++) {
                ports[i] = startPort + i;
            }
        } else {
            ports = getCommonPorts();
        }

        System.out.println("");
        System.out.println("NetScanner v2.1 - Java Network Scanner");
        System.out.println("=======================================");
        System.out.println("Targets: " + ips.size() + " host(s)");
        System.out.println("Ports: " + ports.length);
        System.out.println("Threads: " + threads);
        System.out.println("Timeout: " + timeout + "ms");
        System.out.println("SMB Shares: " + (scanSmb ? "enabled" : "disabled"));
        System.out.println("Unauth Check: enabled");
        System.out.println("=======================================");
        System.out.println("");

        long startTime = System.currentTimeMillis();

        ExecutorService executor = Executors.newFixedThreadPool(threads);
        List<Future<?>> futures = new ArrayList<>();

        for (final String ip : ips) {
            for (final int port : ports) {
                futures.add(executor.submit(new Runnable() {
                    public void run() { scanPort(ip, port); }
                }));
            }
        }

        for (Future<?> f : futures) {
            try {
                f.get(timeout * 3, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                f.cancel(true);
            }
        }

        executor.shutdownNow();
        try { executor.awaitTermination(5, TimeUnit.SECONDS); } catch (Exception e) {}

        if (scanSmb) {
            scanSmbShares();
        }

        long endTime = System.currentTimeMillis();

        printResults();

        if (outputFile != null) {
            saveReport(outputFile);
        }

        System.out.println("\nScan completed in " + (endTime - startTime) / 1000.0 + " seconds");
    }

    static List<String> readTargetsFromFile(String filename) {
        List<String> targets = new ArrayList<>();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                targets.addAll(parseTarget(line));
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found: " + filename);
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        } finally {
            if (reader != null) try { reader.close(); } catch (Exception e) {}
        }
        return targets;
    }

    static void printUsage() {
        System.out.println("NetScanner v2.1 - Java Network Scanner");
        System.out.println("=======================================");
        System.out.println("");
        System.out.println("Usage: java NetScanner <target> [options]");
        System.out.println("       java NetScanner -iL <file> [options]");
        System.out.println("");
        System.out.println("Target formats:");
        System.out.println("  192.168.1.1          Single IP");
        System.out.println("  192.168.1.1-50       IP range");
        System.out.println("  192.168.1.0/24       Subnet (CIDR)");
        System.out.println("  -iL targets.txt      Read from file");
        System.out.println("");
        System.out.println("Options:");
        System.out.println("  -p 1-1000            Port range (default: 92 common ports)");
        System.out.println("  -t 50                Threads (default: 50)");
        System.out.println("  -o report.txt        Output file");
        System.out.println("  --timeout 200        Timeout ms (default: 200)");
        System.out.println("  --noauth             Only unauth-prone ports (41 ports)");
        System.out.println("  --full, -F           Full scan (1-65535)");
        System.out.println("  --no-smb             Skip SMB share scan");
        System.out.println("  --no-banner          Skip banner grabbing");
        System.out.println("  -v                   Verbose output");
        System.out.println("");
        System.out.println("Examples:");
        System.out.println("  java NetScanner 192.168.1.0/24 -o report.txt");
        System.out.println("  java NetScanner -iL targets.txt -o report.txt");
        System.out.println("  java NetScanner 10.0.0.0/24 --noauth");
        System.out.println("  java NetScanner 192.168.1.1 --full -t 100");
        System.out.println("");
        System.out.println("File format (targets.txt):");
        System.out.println("  # Comments start with #");
        System.out.println("  192.168.1.1");
        System.out.println("  192.168.1.10-50");
        System.out.println("  10.0.0.0/24");
    }

    static void scanPort(String ip, int port) {
        Socket socket = null;
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ip, port), timeout);
            
            String banner = "";
            String authStatus = "";
            String httpTitle = "";
            
            if (grabBanners) {
                try {
                    BannerResult br = grabBanner(socket, ip, port);
                    banner = br.banner;
                    authStatus = br.authStatus;
                    httpTitle = br.httpTitle;
                } catch (Exception e) {
                    if (verbose) System.out.println("[DEBUG] Banner failed: " + ip + ":" + port);
                }
            }

            PortResult pr = new PortResult(port, getService(port), banner, authStatus, httpTitle);
            CopyOnWriteArrayList<PortResult> portList = results.get(ip);
            if (portList == null) {
                portList = new CopyOnWriteArrayList<>();
                CopyOnWriteArrayList<PortResult> existing = results.putIfAbsent(ip, portList);
                if (existing != null) portList = existing;
            }
            portList.add(pr);
            
            String output = "[+] " + ip + ":" + port + " OPEN (" + getService(port) + ")";
            if (!httpTitle.isEmpty()) output += " [" + httpTitle + "]";
            else if (!banner.isEmpty()) output += " - " + truncate(banner, 50);
            if (!authStatus.isEmpty()) output += " {" + authStatus + "}";
            System.out.println(output);
        } catch (Exception e) {
            if (verbose) System.out.println("[-] " + ip + ":" + port + " closed");
        } finally {
            if (socket != null) try { socket.close(); } catch (Exception e) {}
        }
    }

    static void scanSmbShares() {
        System.out.println("\n[*] Scanning SMB shares on hosts with port 445/139...");
        
        List<String> smbHosts = new ArrayList<>();
        for (String ip : results.keySet()) {
            for (PortResult pr : results.get(ip)) {
                if (pr.port == 445 || pr.port == 139) {
                    smbHosts.add(ip);
                    break;
                }
            }
        }

        if (smbHosts.isEmpty()) {
            System.out.println("[*] No SMB hosts found");
            return;
        }

        System.out.println("[*] Found " + smbHosts.size() + " host(s) with SMB");

        ExecutorService executor = Executors.newFixedThreadPool(Math.min(threads, smbHosts.size()));
        for (final String ip : smbHosts) {
            executor.submit(new Runnable() {
                public void run() { enumerateSmbShares(ip); }
            });
        }
        executor.shutdown();
        try { executor.awaitTermination(60, TimeUnit.SECONDS); } catch (Exception e) {}
    }

    static void enumerateSmbShares(String ip) {
        String[] commonShares = {
            "ADMIN$", "C$", "D$", "E$", "IPC$", "NETLOGON", "SYSVOL",
            "Users", "Public", "Shared", "Share", "Data", "Files", "Common",
            "Backup", "Backups", "Documents", "Software", "IT", "Admin",
            "Finance", "HR", "Marketing", "Sales", "Dev", "Development",
            "Test", "Temp", "tmp", "www", "wwwroot", "web", "ftp", "home",
            "print$", "Printers", "Scans", "Scan", "Images", "Media",
            "Archive", "Old", "New", "Projects", "Tools", "Scripts"
        };

        CopyOnWriteArrayList<SmbShareInfo> foundShares = new CopyOnWriteArrayList<>();

        for (String share : commonShares) {
            SmbShareInfo info = checkSmbShareAccess(ip, share);
            if (info != null) {
                foundShares.add(info);
                String accessType = info.readable ? (info.writable ? "READ/WRITE" : "READ") : "EXISTS";
                System.out.println("[SMB] \\\\" + ip + "\\" + share + " - " + accessType);
                if (info.files != null && !info.files.isEmpty()) {
                    for (String file : info.files) {
                        System.out.println("      -> " + file);
                    }
                }
            }
        }

        if (!foundShares.isEmpty()) {
            smbShares.put(ip, foundShares);
        }
    }

    static SmbShareInfo checkSmbShareAccess(String ip, String shareName) {
        Socket socket = null;
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ip, 445), timeout);
            socket.setSoTimeout(timeout * 2);
            
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            // SMB1 Negotiate
            byte[] negResp = smbNegotiate(out, in);
            if (negResp == null) return null;

            // SMB1 Session Setup (null session)
            byte[] sessResp = smbSessionSetup(out, in);
            if (sessResp == null) return null;

            // Tree Connect to share
            int treeId = smbTreeConnect(out, in, ip, shareName);
            if (treeId == -1) return null;

            // Share exists! Try to list files
            SmbShareInfo info = new SmbShareInfo();
            info.shareName = shareName;
            info.readable = true;
            info.files = new ArrayList<>();

            // Try to list directory
            List<String> files = smbListFiles(out, in, treeId);
            if (files != null && !files.isEmpty()) {
                info.files = files;
            }

            // Check if writable (by looking for write permissions in share)
            info.writable = false; // Default, would need actual write test

            return info;
        } catch (Exception e) {
            if (verbose) System.out.println("[DEBUG] SMB check failed: " + ip + "/" + shareName + " - " + e.getMessage());
            return null;
        } finally {
            if (socket != null) try { socket.close(); } catch (Exception e) {}
        }
    }

    static byte[] smbNegotiate(DataOutputStream out, DataInputStream in) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream pkt = new DataOutputStream(baos);

        // SMB Header
        pkt.write(new byte[]{(byte)0xFF, 'S', 'M', 'B'}); // Protocol
        pkt.writeByte(0x72); // Negotiate command
        pkt.writeInt(0); // Status
        pkt.writeByte(0x18); // Flags
        pkt.writeShort(0xC853); // Flags2 (little endian issues, simplified)
        pkt.writeShort(0); // PID High
        pkt.write(new byte[8]); // Signature
        pkt.writeShort(0); // Reserved
        pkt.writeShort(0); // TID
        pkt.writeShort(1); // PID
        pkt.writeShort(0); // UID
        pkt.writeShort(0); // MID

        // Negotiate Request
        pkt.writeByte(0); // Word count
        String dialect = "\u0002NT LM 0.12\u0000";
        pkt.writeShort(dialect.length()); // Byte count
        pkt.writeBytes(dialect);

        byte[] smbData = baos.toByteArray();
        
        // NetBIOS header
        out.writeByte(0);
        out.writeByte(0);
        out.writeShort(smbData.length);
        out.write(smbData);
        out.flush();

        // Read response
        byte[] resp = readSmbResponse(in);
        return resp;
    }

    static byte[] smbSessionSetup(DataOutputStream out, DataInputStream in) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream pkt = new DataOutputStream(baos);

        // SMB Header
        pkt.write(new byte[]{(byte)0xFF, 'S', 'M', 'B'});
        pkt.writeByte(0x73); // Session Setup AndX
        pkt.writeInt(0);
        pkt.writeByte(0x18);
        pkt.writeShort(0xC807);
        pkt.writeShort(0);
        pkt.write(new byte[8]);
        pkt.writeShort(0);
        pkt.writeShort(0);
        pkt.writeShort(1);
        pkt.writeShort(0);
        pkt.writeShort(0);

        // Session Setup AndX Request (simplified null session)
        pkt.writeByte(13); // Word count
        pkt.writeByte(0xFF); // AndX command
        pkt.writeByte(0);
        pkt.writeShort(0);
        pkt.writeShort(65535); // Max buffer
        pkt.writeShort(2);
        pkt.writeShort(1);
        pkt.writeInt(0);
        pkt.writeShort(0); // Security blob length
        pkt.writeShort(0);
        pkt.writeInt(0x80000000);
        pkt.writeShort(0); // Byte count

        byte[] smbData = baos.toByteArray();
        out.writeByte(0);
        out.writeByte(0);
        out.writeShort(smbData.length);
        out.write(smbData);
        out.flush();

        return readSmbResponse(in);
    }

    static int smbTreeConnect(DataOutputStream out, DataInputStream in, String ip, String share) throws Exception {
        String path = "\\\\" + ip + "\\" + share;
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream pkt = new DataOutputStream(baos);

        pkt.write(new byte[]{(byte)0xFF, 'S', 'M', 'B'});
        pkt.writeByte(0x75); // Tree Connect AndX
        pkt.writeInt(0);
        pkt.writeByte(0x18);
        pkt.writeShort(0xC807);
        pkt.writeShort(0);
        pkt.write(new byte[8]);
        pkt.writeShort(0);
        pkt.writeShort(0);
        pkt.writeShort(1);
        pkt.writeShort(0); // UID
        pkt.writeShort(0);

        // Tree Connect AndX
        pkt.writeByte(4); // Word count
        pkt.writeByte(0xFF);
        pkt.writeByte(0);
        pkt.writeShort(0);
        pkt.writeShort(0); // Flags
        pkt.writeShort(1); // Password length

        // Byte count and data
        byte[] pathBytes = (path + "\u0000").getBytes("UTF-16LE");
        byte[] service = "?????\u0000".getBytes();
        int byteCount = 1 + pathBytes.length + service.length;
        pkt.writeShort(byteCount);
        pkt.writeByte(0); // Password
        pkt.write(pathBytes);
        pkt.write(service);

        byte[] smbData = baos.toByteArray();
        out.writeByte(0);
        out.writeByte(0);
        out.writeShort(smbData.length);
        out.write(smbData);
        out.flush();

        byte[] resp = readSmbResponse(in);
        if (resp != null && resp.length > 8) {
            // Check NT Status
            int status = ((resp[8] & 0xFF)) | ((resp[7] & 0xFF) << 8) | 
                        ((resp[6] & 0xFF) << 16) | ((resp[5] & 0xFF) << 24);
            if (status == 0) {
                // Success - extract TID
                if (resp.length > 28) {
                    return ((resp[28] & 0xFF) | ((resp[29] & 0xFF) << 8));
                }
                return 1; // Default TID
            }
        }
        return -1;
    }

    static List<String> smbListFiles(DataOutputStream out, DataInputStream in, int treeId) {
        // Simplified - would need full TRANS2_FIND_FIRST2 implementation
        // For now return empty list, the share access check is more important
        return new ArrayList<>();
    }

    static byte[] readSmbResponse(DataInputStream in) throws Exception {
        int type = in.readByte() & 0xFF;
        int flags = in.readByte() & 0xFF;
        int length = in.readShort() & 0xFFFF;
        
        byte[] data = new byte[length];
        in.readFully(data);
        return data;
    }

    static BannerResult grabBanner(Socket socket, String ip, int port) {
        String banner = "";
        String authStatus = "";
        String httpTitle = "";
        
        try {
            socket.setSoTimeout(timeout * 2);
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();

            switch (port) {
                case 80: case 443: case 8080: case 8081: case 8443:
                case 8000: case 8008: case 8888: case 3000: case 9090:
                    HttpResult hr = httpGetWithTitle(ip, port, "/");
                    banner = hr.server;
                    httpTitle = hr.title;
                    break;

                case 9200: case 9201:
                    HttpResult es = httpGetWithTitle(ip, port, "/");
                    if (es.body.contains("cluster_name") || es.body.contains("lucene")) {
                        authStatus = "NO AUTH - Elasticsearch!";
                        Matcher m = Pattern.compile("\"number\"\\s*:\\s*\"([^\"]+)\"").matcher(es.body);
                        if (m.find()) httpTitle = "Elasticsearch " + m.group(1);
                    }
                    banner = truncate(es.body, 50);
                    break;

                case 5984:
                    HttpResult couch = httpGetWithTitle(ip, port, "/");
                    if (couch.body.contains("couchdb")) {
                        authStatus = "NO AUTH - CouchDB!";
                        httpTitle = "CouchDB";
                    }
                    break;

                case 5601:
                    HttpResult kib = httpGetWithTitle(ip, port, "/api/status");
                    if (kib.body.contains("kibana") || kib.body.contains("available")) {
                        authStatus = "NO AUTH - Kibana!";
                        httpTitle = "Kibana";
                    }
                    break;

                case 2181:
                    out.write("stat\n".getBytes());
                    out.flush();
                    banner = readResponse(in);
                    if (banner.contains("Zookeeper") || banner.contains("version")) {
                        authStatus = "NO AUTH - ZooKeeper!";
                    }
                    break;

                case 6379:
                    out.write("INFO\r\n".getBytes());
                    out.flush();
                    banner = readResponse(in);
                    if (banner.contains("redis_version")) {
                        authStatus = "NO AUTH - Redis!";
                        Matcher m = Pattern.compile("redis_version:([^\\r\\n]+)").matcher(banner);
                        if (m.find()) httpTitle = "Redis " + m.group(1);
                    } else if (banner.contains("NOAUTH")) {
                        authStatus = "Auth required";
                    }
                    break;

                case 27017: case 27018:
                    banner = "MongoDB";
                    authStatus = "Check auth";
                    break;

                case 11211:
                    out.write("stats\r\n".getBytes());
                    out.flush();
                    banner = readResponse(in);
                    if (banner.contains("STAT")) {
                        authStatus = "NO AUTH - Memcached!";
                    }
                    break;

                case 8500:
                    HttpResult consul = httpGetWithTitle(ip, port, "/v1/agent/self");
                    if (consul.body.contains("Config") || consul.body.contains("Member")) {
                        authStatus = "NO AUTH - Consul!";
                        httpTitle = "Consul";
                    }
                    break;

                case 2379: case 2380:
                    HttpResult etcd = httpGetWithTitle(ip, port, "/version");
                    if (etcd.body.contains("etcdserver")) {
                        authStatus = "NO AUTH - etcd!";
                        httpTitle = "etcd";
                    }
                    break;

                case 2375:
                    HttpResult docker = httpGetWithTitle(ip, port, "/version");
                    if (docker.body.contains("ApiVersion") || docker.body.contains("Version")) {
                        authStatus = "CRITICAL - Docker API NO AUTH!";
                        httpTitle = "Docker";
                    }
                    break;

                case 6443:
                    HttpResult k8s = httpGetWithTitle(ip, port, "/version");
                    if (k8s.body.contains("gitVersion")) {
                        authStatus = "Kubernetes API";
                        httpTitle = "Kubernetes";
                    }
                    break;

                case 10250: case 10255:
                    HttpResult kubelet = httpGetWithTitle(ip, port, "/pods");
                    if (kubelet.body.contains("items") || kubelet.body.contains("metadata")) {
                        authStatus = "NO AUTH - Kubelet!";
                    }
                    break;

                case 15672:
                    HttpResult rabbit = httpGetWithTitle(ip, port, "/");
                    httpTitle = rabbit.title;
                    if (httpTitle.toLowerCase().contains("rabbitmq")) {
                        authStatus = "Try guest:guest";
                    }
                    break;

                case 50070: case 50075: case 50090: case 8088:
                    HttpResult hadoop = httpGetWithTitle(ip, port, "/");
                    httpTitle = hadoop.title;
                    if (hadoop.body.contains("Hadoop") || hadoop.body.contains("NameNode")) {
                        authStatus = "NO AUTH - Hadoop!";
                    }
                    break;

                case 8983:
                    HttpResult solr = httpGetWithTitle(ip, port, "/solr/");
                    if (solr.body.contains("solr")) {
                        authStatus = "NO AUTH - Solr!";
                        httpTitle = "Solr";
                    }
                    break;

                case 7474:
                    HttpResult neo = httpGetWithTitle(ip, port, "/");
                    httpTitle = neo.title;
                    if (neo.body.contains("neo4j")) authStatus = "Try neo4j:neo4j";
                    break;

                case 5000:
                    HttpResult reg = httpGetWithTitle(ip, port, "/v2/");
                    if (reg.body.contains("{}") || !reg.body.contains("401")) {
                        authStatus = "NO AUTH - Docker Registry!";
                    }
                    break;

                case 21:
                    banner = readResponse(in);
                    if (banner.toLowerCase().contains("anonymous")) authStatus = "Anonymous FTP!";
                    break;

                case 22:
                    banner = readResponse(in);
                    break;

                case 389: case 636: case 3268: case 3269:
                    banner = "LDAP";
                    authStatus = "Check anon bind";
                    break;

                case 445: case 139:
                    banner = "SMB";
                    break;

                case 3306:
                    banner = readResponse(in);
                    if (banner.toLowerCase().contains("mysql")) banner = "MySQL";
                    break;

                case 1433: banner = "MSSQL"; break;
                case 5432: banner = "PostgreSQL"; break;
                case 1521: banner = "Oracle"; break;
                case 3389: banner = "RDP"; break;

                default:
                    HttpResult unknown = httpGetWithTitle(ip, port, "/");
                    if (!unknown.title.isEmpty()) {
                        httpTitle = unknown.title;
                        banner = unknown.server;
                    } else {
                        try {
                            byte[] buf = new byte[512];
                            socket.setSoTimeout(timeout);
                            int len = in.read(buf);
                            if (len > 0) banner = truncate(cleanBanner(new String(buf, 0, len)), 50);
                        } catch (Exception e) {}
                    }
                    break;
            }
        } catch (Exception e) {}

        return new BannerResult(cleanBanner(banner), authStatus, cleanBanner(httpTitle));
    }

    static HttpResult httpGetWithTitle(String host, int port, String path) {
        HttpResult result = new HttpResult();
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress(host, port), timeout);
            s.setSoTimeout(timeout * 3);

            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

            out.print("GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\n");
            out.print("User-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n");
            out.flush();

            StringBuilder sb = new StringBuilder();
            String line;
            int lines = 0;
            while ((line = in.readLine()) != null && lines++ < 100) {
                if (line.toLowerCase().startsWith("server:")) 
                    result.server = line.substring(7).trim();
                sb.append(line).append("\n");
            }
            result.body = sb.toString();

            Matcher m = Pattern.compile("<title[^>]*>([^<]+)</title>", Pattern.CASE_INSENSITIVE).matcher(result.body);
            if (m.find()) result.title = m.group(1).trim();

        } catch (Exception e) {}
        finally { if (s != null) try { s.close(); } catch (Exception e) {} }
        return result;
    }

    static String readResponse(InputStream in) {
        try {
            byte[] buf = new byte[1024];
            int len = in.read(buf);
            if (len > 0) return new String(buf, 0, len).trim();
        } catch (Exception e) {}
        return "";
    }

    static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    static String cleanBanner(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\r\\n\\t]+", " ").replaceAll("[^\\x20-\\x7E]", "").trim();
    }

    static List<String> parseTarget(String target) {
        List<String> ips = new ArrayList<>();
        try {
            if (target.contains("/")) {
                String[] parts = target.split("/");
                String baseIP = parts[0];
                int prefix = Integer.parseInt(parts[1]);
                
                String[] octets = baseIP.split("\\.");
                if (octets.length != 4) { ips.add(target); return ips; }
                
                long ip = 0;
                for (int i = 0; i < 4; i++) ip = (ip << 8) | Integer.parseInt(octets[i]);
                
                int hostBits = 32 - prefix;
                long numHosts = (1L << hostBits) - 2;
                long networkAddr = ip & (0xFFFFFFFFL << hostBits);
                
                for (long i = 1; i <= Math.min(numHosts, 65534); i++) {
                    long addr = networkAddr + i;
                    ips.add(((addr >> 24) & 0xFF) + "." + ((addr >> 16) & 0xFF) + "." +
                           ((addr >> 8) & 0xFF) + "." + (addr & 0xFF));
                }
            } else if (target.contains("-")) {
                String[] parts = target.split("\\.");
                if (parts.length == 4 && parts[3].contains("-")) {
                    String[] range = parts[3].split("-");
                    String base = parts[0] + "." + parts[1] + "." + parts[2] + ".";
                    for (int i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++) {
                        ips.add(base + i);
                    }
                } else ips.add(target);
            } else {
                ips.add(target);
            }
        } catch (Exception e) {
            ips.add(target);
        }
        return ips;
    }

    static void printResults() {
        System.out.println("\n==========================================");
        System.out.println("SCAN RESULTS");
        System.out.println("==========================================");

        List<String> sortedIPs = new ArrayList<>(results.keySet());
        Collections.sort(sortedIPs, new Comparator<String>() {
            public int compare(String a, String b) {
                try {
                    String[] pa = a.split("\\."), pb = b.split("\\.");
                    for (int i = 0; i < 4; i++) {
                        int c = Integer.compare(Integer.parseInt(pa[i]), Integer.parseInt(pb[i]));
                        if (c != 0) return c;
                    }
                } catch (Exception e) {}
                return a.compareTo(b);
            }
        });

        int noAuthCount = 0;
        int shareCount = 0;

        for (String ip : sortedIPs) {
            CopyOnWriteArrayList<PortResult> ports = results.get(ip);
            if (ports == null || ports.isEmpty()) continue;

            List<PortResult> portList = new ArrayList<>(ports);
            Collections.sort(portList, new Comparator<PortResult>() {
                public int compare(PortResult a, PortResult b) { return Integer.compare(a.port, b.port); }
            });

            System.out.println("\nHost: " + ip);
            System.out.println("------------------------");
            for (PortResult pr : portList) {
                String line = "  " + pr.port + "/tcp\t" + pr.service;
                if (pr.httpTitle != null && !pr.httpTitle.isEmpty()) line += "\t[" + pr.httpTitle + "]";
                else if (pr.banner != null && !pr.banner.isEmpty()) line += "\t" + pr.banner;
                System.out.println(line);
                if (pr.authStatus != null && !pr.authStatus.isEmpty()) {
                    System.out.println("    [!] " + pr.authStatus);
                    if (pr.authStatus.contains("NO AUTH") || pr.authStatus.contains("CRITICAL")) noAuthCount++;
                }
            }

            CopyOnWriteArrayList<SmbShareInfo> shares = smbShares.get(ip);
            if (shares != null && !shares.isEmpty()) {
                System.out.println("  SMB Shares:");
                for (SmbShareInfo share : shares) {
                    String access = share.readable ? (share.writable ? "RW" : "R") : "";
                    System.out.println("    \\\\" + ip + "\\" + share.shareName + " [" + access + "]");
                    if (share.files != null) {
                        for (String f : share.files) System.out.println("      -> " + f);
                    }
                    shareCount++;
                }
            }
        }

        if (results.isEmpty()) System.out.println("No open ports found.");

        if (noAuthCount > 0 || shareCount > 0) {
            System.out.println("\n==========================================");
            System.out.println("SECURITY FINDINGS");
            System.out.println("==========================================");
            if (noAuthCount > 0) System.out.println("[!] " + noAuthCount + " unauthenticated service(s)");
            if (shareCount > 0) System.out.println("[!] " + shareCount + " SMB share(s) accessible");
        }
    }

    static void saveReport(String filename) {
        PrintWriter w = null;
        try {
            w = new PrintWriter(new FileWriter(filename));
            w.println("NetScanner Security Report v2.1");
            w.println("Generated: " + new Date());
            w.println("==========================================\n");

            List<String> sortedIPs = new ArrayList<>(results.keySet());
            Collections.sort(sortedIPs, new Comparator<String>() {
                public int compare(String a, String b) {
                    try {
                        String[] pa = a.split("\\."), pb = b.split("\\.");
                        for (int i = 0; i < 4; i++) {
                            int c = Integer.compare(Integer.parseInt(pa[i]), Integer.parseInt(pb[i]));
                            if (c != 0) return c;
                        }
                    } catch (Exception e) {}
                    return a.compareTo(b);
                }
            });

            List<String> findings = new ArrayList<>();

            for (String ip : sortedIPs) {
                CopyOnWriteArrayList<PortResult> ports = results.get(ip);
                if (ports == null || ports.isEmpty()) continue;

                List<PortResult> portList = new ArrayList<>(ports);
                Collections.sort(portList, new Comparator<PortResult>() {
                    public int compare(PortResult a, PortResult b) { return Integer.compare(a.port, b.port); }
                });

                w.println("Host: " + ip);
                w.println("Open ports:");
                for (PortResult pr : portList) {
                    String line = "  " + pr.port + "/tcp\t" + pr.service;
                    if (pr.httpTitle != null && !pr.httpTitle.isEmpty()) line += "\t[" + pr.httpTitle + "]";
                    if (pr.banner != null && !pr.banner.isEmpty()) line += "\t" + pr.banner;
                    w.println(line);
                    if (pr.authStatus != null && !pr.authStatus.isEmpty()) {
                        w.println("    Status: " + pr.authStatus);
                        if (pr.authStatus.contains("NO AUTH") || pr.authStatus.contains("CRITICAL")) {
                            findings.add(ip + ":" + pr.port + " - " + pr.service + " - " + pr.authStatus);
                        }
                    }
                }

                CopyOnWriteArrayList<SmbShareInfo> shares = smbShares.get(ip);
                if (shares != null && !shares.isEmpty()) {
                    w.println("  SMB Shares:");
                    for (SmbShareInfo share : shares) {
                        String access = share.readable ? (share.writable ? "RW" : "R") : "";
                        w.println("    \\\\" + ip + "\\" + share.shareName + " [" + access + "]");
                        findings.add("\\\\" + ip + "\\" + share.shareName + " - SMB Share Accessible");
                        if (share.files != null) {
                            for (String f : share.files) w.println("      -> " + f);
                        }
                    }
                }
                w.println();
            }

            if (!findings.isEmpty()) {
                w.println("==========================================");
                w.println("SECURITY FINDINGS");
                w.println("==========================================");
                for (String f : findings) w.println("[!] " + f);
            }

            System.out.println("\nReport saved to: " + filename);
        } catch (Exception e) {
            System.out.println("Error saving: " + e.getMessage());
        } finally {
            if (w != null) w.close();
        }
    }

    static int[] getNoAuthPorts() {
        return new int[] {
            139, 445, 1099, 2181, 2375, 2376, 2379, 2380, 3000, 4444,
            5000, 5601, 5672, 5984, 6379, 6443, 7199, 7474, 8086, 8088,
            8500, 8983, 9000, 9042, 9092, 9160, 9200, 9201, 9300, 9999,
            10000, 10250, 10255, 11211, 15672, 27017, 27018, 28017,
            50070, 50075, 50090
        };
    }

    static int[] getCommonPorts() {
        return new int[] {
            21, 22, 23, 25, 53, 80, 88, 110, 111, 135, 139, 143, 161, 162,
            389, 443, 445, 464, 465, 514, 587, 636, 993, 995, 1099,
            1080, 1433, 1434, 1521, 1723, 2049, 2181, 2375, 2376, 2379, 2380,
            3000, 3268, 3269, 3306, 3389, 4443, 4444, 5000, 5060, 5061,
            5432, 5500, 5601, 5672, 5900, 5984, 5985, 5986, 6379, 6443,
            7001, 7002, 7199, 7474, 8000, 8008, 8080, 8081, 8086, 8088, 8443,
            8500, 8888, 8983, 9000, 9042, 9090, 9092, 9160, 9200, 9300, 9443, 9999,
            10000, 10250, 10255, 11211, 15672, 27017, 27018, 28017,
            50000, 50070, 50075, 50090
        };
    }

    static String getService(int port) {
        switch (port) {
            case 21: return "FTP"; case 22: return "SSH"; case 23: return "Telnet";
            case 25: return "SMTP"; case 53: return "DNS"; case 80: return "HTTP";
            case 88: return "Kerberos"; case 110: return "POP3"; case 111: return "RPC";
            case 135: return "MSRPC"; case 139: return "NetBIOS"; case 143: return "IMAP";
            case 161: return "SNMP"; case 389: return "LDAP"; case 443: return "HTTPS";
            case 445: return "SMB"; case 465: return "SMTPS"; case 587: return "SMTP";
            case 636: return "LDAPS"; case 993: return "IMAPS"; case 995: return "POP3S";
            case 1099: return "JMX"; case 1433: return "MSSQL"; case 1521: return "Oracle";
            case 2181: return "ZooKeeper"; case 2375: return "Docker"; case 2379: return "etcd";
            case 3000: return "Grafana"; case 3268: return "LDAP-GC"; case 3306: return "MySQL";
            case 3389: return "RDP"; case 5000: return "Registry"; case 5432: return "PostgreSQL";
            case 5601: return "Kibana"; case 5672: return "RabbitMQ"; case 5900: return "VNC";
            case 5984: return "CouchDB"; case 5985: return "WinRM"; case 6379: return "Redis";
            case 6443: return "K8s-API"; case 7474: return "Neo4j"; case 8080: return "HTTP-Proxy";
            case 8086: return "InfluxDB"; case 8088: return "YARN"; case 8443: return "HTTPS-Alt";
            case 8500: return "Consul"; case 8983: return "Solr"; case 9000: return "ClickHouse";
            case 9042: return "Cassandra"; case 9092: return "Kafka"; case 9200: return "Elastic";
            case 9300: return "Elastic"; case 10250: return "Kubelet"; case 11211: return "Memcached";
            case 15672: return "RabbitMQ"; case 27017: return "MongoDB"; case 50070: return "Hadoop";
            default: return "unknown";
        }
    }

    static class PortResult {
        int port; String service, banner, authStatus, httpTitle;
        PortResult(int p, String s, String b, String a, String t) {
            port = p; service = s; banner = b; authStatus = a; httpTitle = t;
        }
    }

    static class BannerResult {
        String banner, authStatus, httpTitle;
        BannerResult(String b, String a, String t) { banner = b; authStatus = a; httpTitle = t; }
    }

    static class HttpResult { String title = "", server = "", body = ""; }

    static class SmbShareInfo {
        String shareName;
        boolean readable, writable;
        List<String> files;
    }
}