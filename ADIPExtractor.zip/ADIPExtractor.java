import java.io.*;
import java.util.*;
import java.util.regex.*;
import javax.naming.*;
import javax.naming.directory.*;

public class ADIPExtractor {
    static boolean verbose = false;

    public static void main(String[] args) {
        String ldapServer = null;
        String baseDN = null;
        String username = null;
        String password = null;
        String outputFile = "ad_ips.txt";
        boolean includeDisabled = false;

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-s") && i + 1 < args.length) {
                ldapServer = args[++i];
            } else if (args[i].equals("-d") && i + 1 < args.length) {
                baseDN = args[++i];
            } else if (args[i].equals("-u") && i + 1 < args.length) {
                username = args[++i];
            } else if (args[i].equals("-p") && i + 1 < args.length) {
                password = args[++i];
            } else if (args[i].equals("-o") && i + 1 < args.length) {
                outputFile = args[++i];
            } else if (args[i].equals("--include-disabled")) {
                includeDisabled = true;
            } else if (args[i].equals("-v")) {
                verbose = true;
            } else if (args[i].equals("-h") || args[i].equals("--help")) {
                printUsage();
                return;
            }
        }

        // Auto-detect DC
        if (ldapServer == null) {
            ldapServer = System.getenv("LOGONSERVER");
            if (ldapServer != null) {
                ldapServer = ldapServer.replace("\\\\", "").replace("\\", "");
            }
            if (ldapServer == null || ldapServer.isEmpty()) {
                System.out.println("Error: Cannot detect DC. Use -s <server>");
                printUsage();
                return;
            }
            System.out.println("[*] Auto-detected DC: " + ldapServer);
        }

        // Auto-detect Base DN from USERDNSDOMAIN
        if (baseDN == null) {
            String dnsDomain = System.getenv("USERDNSDOMAIN");
            if (dnsDomain != null && !dnsDomain.isEmpty()) {
                String[] parts = dnsDomain.split("\\.");
                StringBuilder dn = new StringBuilder();
                for (String part : parts) {
                    if (dn.length() > 0) dn.append(",");
                    dn.append("DC=").append(part);
                }
                baseDN = dn.toString();
            } else {
                System.out.println("Error: Cannot detect domain. Use -d <baseDN>");
                System.out.println("Example: -d \"DC=DTEKGROUP,DC=TEK,DC=LOC\"");
                return;
            }
            System.out.println("[*] Auto-detected Base DN: " + baseDN);
        }

        System.out.println("");
        System.out.println("AD IP Extractor v1.4");
        System.out.println("====================");
        System.out.println("Server: " + ldapServer);
        System.out.println("Base DN: " + baseDN);
        System.out.println("Auth: " + (username != null ? username : "Anonymous"));
        System.out.println("Output: " + outputFile);
        System.out.println("====================");
        System.out.println("");

        DirContext ctx = null;
        
        try {
            // Connection methods to try (in order)
            String[][] methods = {
                {"ldaps", "636"},   // LDAPS (SSL)
                {"ldap", "3269"},   // Global Catalog SSL
                {"ldap", "3268"},   // Global Catalog
                {"ldap", "389"}     // Plain LDAP
            };
            
            for (String[] method : methods) {
                String protocol = method[0];
                String port = method[1];
                
                System.out.println("[*] Trying " + protocol.toUpperCase() + " port " + port + "...");
                
                try {
                    Hashtable<String, String> env = new Hashtable<>();
                    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
                    env.put(Context.PROVIDER_URL, protocol + "://" + ldapServer + ":" + port);
                    env.put("com.sun.jndi.ldap.connect.timeout", "5000");
                    env.put("com.sun.jndi.ldap.read.timeout", "30000");
                    
                    if (protocol.equals("ldaps")) {
                        env.put(Context.SECURITY_PROTOCOL, "ssl");
                    }
                    
                    if (username != null && password != null) {
                        env.put(Context.SECURITY_AUTHENTICATION, "simple");
                        env.put(Context.SECURITY_PRINCIPAL, username);
                        env.put(Context.SECURITY_CREDENTIALS, password);
                    } else {
                        env.put(Context.SECURITY_AUTHENTICATION, "none");
                    }
                    
                    ctx = new InitialDirContext(env);
                    System.out.println("[+] Connected via " + protocol.toUpperCase() + ":" + port);
                    break;
                } catch (Exception e) {
                    String msg = e.getMessage();
                    if (msg != null && msg.length() > 80) msg = msg.substring(0, 80) + "...";
                    System.out.println("    Failed: " + msg);
                }
            }
            
            if (ctx == null) {
                System.out.println("\n[-] All connection methods failed!");
                System.out.println("Check:");
                System.out.println("  1. Username format: user@DTEKGROUP.TEK.LOC");
                System.out.println("  2. Password is correct");
                System.out.println("  3. Ports 636, 3268, 3269, 389 accessible");
                return;
            }

            // Collect results
            Set<String> allIPs = new TreeSet<>(new IPComparator());
            Set<String> allHostnames = new TreeSet<>();

            // Search for computers
            System.out.println("\n[*] Searching for computers...");
            searchComputers(ctx, baseDN, includeDisabled, allIPs, allHostnames);
            System.out.println("[+] Found " + allHostnames.size() + " computer(s)");

            // Resolve hostnames to IPs
            System.out.println("\n[*] Resolving hostnames to IPs...");
            int resolved = 0;
            for (String hostname : allHostnames) {
                try {
                    java.net.InetAddress[] addrs = java.net.InetAddress.getAllByName(hostname);
                    for (java.net.InetAddress addr : addrs) {
                        String ip = addr.getHostAddress();
                        if (!ip.contains(":") && !ip.startsWith("127.")) {
                            allIPs.add(ip);
                            resolved++;
                            if (verbose) System.out.println("    " + hostname + " -> " + ip);
                        }
                    }
                } catch (Exception e) {
                    if (verbose) System.out.println("    " + hostname + " -> [unresolved]");
                }
            }
            System.out.println("[+] Resolved " + resolved + " IP(s)");

            // Save IPs
            PrintWriter ipWriter = new PrintWriter(new FileWriter(outputFile));
            ipWriter.println("# AD IPs - " + new Date());
            ipWriter.println("# Total: " + allIPs.size());
            for (String ip : allIPs) {
                ipWriter.println(ip);
            }
            ipWriter.close();

            // Save hostnames
            String hostFile = outputFile.replace(".txt", "_hostnames.txt");
            PrintWriter hostWriter = new PrintWriter(new FileWriter(hostFile));
            hostWriter.println("# AD Hostnames - " + new Date());
            hostWriter.println("# Total: " + allHostnames.size());
            for (String host : allHostnames) {
                hostWriter.println(host);
            }
            hostWriter.close();

            ctx.close();

            System.out.println("\n====================");
            System.out.println("DONE!");
            System.out.println("====================");
            System.out.println("Total IPs: " + allIPs.size());
            System.out.println("Total Hostnames: " + allHostnames.size());
            System.out.println("\nFiles:");
            System.out.println("  " + outputFile);
            System.out.println("  " + hostFile);
            System.out.println("\nNext: java NetScanner -iL " + outputFile + " -o scan.txt");

        } catch (Exception e) {
            System.out.println("[-] Error: " + e.getMessage());
            if (verbose) e.printStackTrace();
        }
    }

    static void searchComputers(DirContext ctx, String baseDN, boolean includeDisabled, 
                                 Set<String> ips, Set<String> hostnames) {
        try {
            SearchControls controls = new SearchControls();
            controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            controls.setReturningAttributes(new String[]{
                "cn", "dNSHostName", "operatingSystem", "servicePrincipalName"
            });

            String filter = includeDisabled ? 
                "(objectClass=computer)" :
                "(&(objectClass=computer)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))";

            NamingEnumeration<SearchResult> results = ctx.search(baseDN, filter, controls);

            while (results.hasMore()) {
                SearchResult sr = results.next();
                Attributes attrs = sr.getAttributes();

                String hostname = getAttr(attrs, "dNSHostName");
                if (hostname == null || hostname.isEmpty()) {
                    hostname = getAttr(attrs, "cn");
                }
                if (hostname != null && !hostname.isEmpty()) {
                    hostnames.add(hostname.toLowerCase());
                    if (verbose) {
                        String os = getAttr(attrs, "operatingSystem");
                        System.out.println("    " + hostname + (os != null ? " (" + os + ")" : ""));
                    }
                }

                Attribute spn = attrs.get("servicePrincipalName");
                if (spn != null) {
                    for (int i = 0; i < spn.size(); i++) {
                        String val = (String) spn.get(i);
                        if (val != null && val.contains("/")) {
                            String host = val.split("/")[1];
                            if (host.contains(":")) host = host.split(":")[0];
                            if (!host.isEmpty()) hostnames.add(host.toLowerCase());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("    Search error: " + e.getMessage());
        }
    }

    static String getAttr(Attributes attrs, String name) {
        try {
            Attribute attr = attrs.get(name);
            if (attr != null) return attr.get().toString();
        } catch (Exception e) {}
        return null;
    }

    static void printUsage() {
        System.out.println("AD IP Extractor v1.4");
        System.out.println("====================");
        System.out.println("");
        System.out.println("Usage: java ADIPExtractor -u <user> -p <pass> [options]");
        System.out.println("");
        System.out.println("Required:");
        System.out.println("  -u <user>    Username (user@domain.com)");
        System.out.println("  -p <pass>    Password");
        System.out.println("");
        System.out.println("Optional:");
        System.out.println("  -s <server>  DC hostname (auto-detected)");
        System.out.println("  -d <baseDN>  Base DN (auto-detected)");
        System.out.println("  -o <file>    Output file (default: ad_ips.txt)");
        System.out.println("  -v           Verbose");
        System.out.println("");
        System.out.println("Example:");
        System.out.println("  java ADIPExtractor -u user@domain.com -p Pass123");
    }

    static class IPComparator implements Comparator<String> {
        public int compare(String a, String b) {
            try {
                String[] pa = a.split("\\.");
                String[] pb = b.split("\\.");
                for (int i = 0; i < 4; i++) {
                    int cmp = Integer.compare(Integer.parseInt(pa[i]), Integer.parseInt(pb[i]));
                    if (cmp != 0) return cmp;
                }
            } catch (Exception e) {}
            return a.compareTo(b);
        }
    }
}
