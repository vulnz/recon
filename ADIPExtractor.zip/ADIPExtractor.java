import java.io.*;
import java.util.*;
import java.util.regex.*;
import javax.naming.*;
import javax.naming.directory.*;
import javax.security.auth.login.*;
import javax.security.auth.Subject;
import java.security.PrivilegedAction;

public class ADIPExtractor {
    
    public static void main(String[] args) {
        String ldapServer = null;
        String baseDN = null;
        String username = null;
        String password = null;
        String outputFile = "ad_ips.txt";
        boolean includeDisabled = false;
        boolean verbose = false;
        boolean useIntegratedAuth = false;
        boolean showHelp = false;

        // Parse arguments
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-s") && i + 1 < args.length) {
                ldapServer = args[++i];
            } else if (args[i].equals("-d") && i + 1 < args.length) {
                baseDN = args[++i];
            } else if (args[i].equals("-u") && i + 1 < args.length) {
                username = args[++i];
            } else if (args[i].equals("-p") && i + 1 < args.length) {
                password = args[++i];
            } else if (args[i].equals("-o") && i + 1 < args.length) {
                outputFile = args[++i];
            } else if (args[i].equals("--include-disabled")) {
                includeDisabled = true;
            } else if (args[i].equals("-v")) {
                verbose = true;
            } else if (args[i].equals("-k") || args[i].equals("--kerberos") || args[i].equals("--integrated")) {
                useIntegratedAuth = true;
            } else if (args[i].equals("-h") || args[i].equals("--help")) {
                showHelp = true;
            }
        }

        if (showHelp) {
            printUsage();
            return;
        }

        if (ldapServer == null) {
            // Try to auto-detect DC from environment
            ldapServer = detectDomainController();
            if (ldapServer == null) {
                System.out.println("Error: Could not auto-detect DC. Please specify with -s");
                printUsage();
                return;
            }
            System.out.println("[*] Auto-detected DC: " + ldapServer);
        }

        // Auto-generate baseDN from server if not provided
        if (baseDN == null) {
            baseDN = serverToBaseDN(ldapServer);
            System.out.println("[*] Auto-detected Base DN: " + baseDN);
        }

        String authMethod = "Anonymous";
        if (useIntegratedAuth) {
            authMethod = "Integrated (Kerberos/NTLM)";
        } else if (username != null) {
            authMethod = username;
        }

        System.out.println("");
        System.out.println("AD IP Extractor v1.1");
        System.out.println("====================");
        System.out.println("Server: " + ldapServer);
        System.out.println("Base DN: " + baseDN);
        System.out.println("Auth: " + authMethod);
        System.out.println("Output: " + outputFile);
        System.out.println("====================");
        System.out.println("");

        try {
            // Setup LDAP connection
            Hashtable<String, String> env = new Hashtable<>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            env.put(Context.PROVIDER_URL, "ldap://" + ldapServer + ":389");
            
            if (useIntegratedAuth) {
                // Use GSSAPI (Kerberos) - uses current Windows login
                env.put(Context.SECURITY_AUTHENTICATION, "GSSAPI");
                // Set up Kerberos properties
                System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
                // For Windows integrated auth
                System.setProperty("java.security.auth.login.config", createJaasConfig());
            } else if (username != null && password != null) {
                env.put(Context.SECURITY_AUTHENTICATION, "simple");
                env.put(Context.SECURITY_PRINCIPAL, username);
                env.put(Context.SECURITY_CREDENTIALS, password);
            } else {
                env.put(Context.SECURITY_AUTHENTICATION, "none");
            }

            // Connection timeout
            env.put("com.sun.jndi.ldap.connect.timeout", "5000");
            env.put("com.sun.jndi.ldap.read.timeout", "10000");

            System.out.println("[*] Connecting to LDAP server...");
            if (useIntegratedAuth) {
                System.out.println("[*] Using current Windows credentials...");
            }
            DirContext ctx = new InitialDirContext(env);
            System.out.println("[+] Connected successfully!");

            Set<String> allIPs = new TreeSet<>(new IPComparator());
            Set<String> allHostnames = new TreeSet<>();

            // 1. Get Computer objects
            System.out.println("\n[*] Searching for Computer objects...");
            SearchResult computerResult = searchComputers(ctx, baseDN, includeDisabled, verbose);
            allIPs.addAll(computerResult.ips);
            allHostnames.addAll(computerResult.hostnames);
            System.out.println("[+] Found " + computerResult.count + " computers");

            // 2. Get DNS records from AD-integrated DNS
            System.out.println("\n[*] Searching DNS zones...");
            SearchResult dnsResult = searchDNSRecords(ctx, baseDN, verbose);
            allIPs.addAll(dnsResult.ips);
            System.out.println("[+] Found " + dnsResult.ips.size() + " IPs from DNS");

            // 3. Get DHCP leases if available
            System.out.println("\n[*] Searching for DHCP information...");
            SearchResult dhcpResult = searchDHCP(ctx, baseDN, verbose);
            allIPs.addAll(dhcpResult.ips);
            System.out.println("[+] Found " + dhcpResult.ips.size() + " IPs from DHCP");

            // 4. Resolve hostnames to IPs
            System.out.println("\n[*] Resolving hostnames to IPs...");
            int resolved = 0;
            for (String hostname : allHostnames) {
                try {
                    java.net.InetAddress[] addresses = java.net.InetAddress.getAllByName(hostname);
                    for (java.net.InetAddress addr : addresses) {
                        String ip = addr.getHostAddress();
                        if (isValidIP(ip) && !ip.startsWith("127.")) {
                            allIPs.add(ip);
                            resolved++;
                            if (verbose) System.out.println("    " + hostname + " -> " + ip);
                        }
                    }
                } catch (Exception e) {
                    if (verbose) System.out.println("    " + hostname + " -> [unresolved]");
                }
            }
            System.out.println("[+] Resolved " + resolved + " additional IPs from hostnames");

            // Save results
            System.out.println("\n[*] Saving results...");
            PrintWriter writer = new PrintWriter(new FileWriter(outputFile));
            writer.println("# AD IP Extract - " + new Date());
            writer.println("# Server: " + ldapServer);
            writer.println("# Total IPs: " + allIPs.size());
            writer.println("#");
            for (String ip : allIPs) {
                writer.println(ip);
            }
            writer.close();

            // Also save hostnames
            String hostnameFile = outputFile.replace(".txt", "_hostnames.txt");
            PrintWriter hostWriter = new PrintWriter(new FileWriter(hostnameFile));
            hostWriter.println("# AD Hostnames - " + new Date());
            hostWriter.println("# Total: " + allHostnames.size());
            hostWriter.println("#");
            for (String host : allHostnames) {
                hostWriter.println(host);
            }
            hostWriter.close();

            ctx.close();

            System.out.println("");
            System.out.println("==========================================");
            System.out.println("RESULTS");
            System.out.println("==========================================");
            System.out.println("Total unique IPs: " + allIPs.size());
            System.out.println("Total hostnames: " + allHostnames.size());
            System.out.println("");
            System.out.println("Files saved:");
            System.out.println("  IPs: " + outputFile);
            System.out.println("  Hostnames: " + hostnameFile);
            System.out.println("");
            System.out.println("Use with NetScanner:");
            System.out.println("  java NetScanner -iL " + outputFile + " -o scan_report.txt");

        } catch (AuthenticationException e) {
            System.out.println("[-] Authentication failed: " + e.getMessage());
            System.out.println("    Try with valid credentials: -u user@domain.com -p password");
        } catch (CommunicationException e) {
            System.out.println("[-] Cannot connect to server: " + e.getMessage());
            System.out.println("    Check if LDAP port 389 is open");
        } catch (Exception e) {
            System.out.println("[-] Error: " + e.getMessage());
            if (verbose) e.printStackTrace();
        }
    }

    static SearchResult searchComputers(DirContext ctx, String baseDN, boolean includeDisabled, boolean verbose) {
        SearchResult result = new SearchResult();
        
        try {
            SearchControls controls = new SearchControls();
            controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            controls.setReturningAttributes(new String[]{
                "cn", "dNSHostName", "operatingSystem", "operatingSystemVersion",
                "lastLogonTimestamp", "userAccountControl", "servicePrincipalName",
                "networkAddress", "msDS-AdditionalDnsHostName"
            });

            // Search for all computer objects
            String filter = "(objectClass=computer)";
            if (!includeDisabled) {
                // Exclude disabled accounts (bit 2 of userAccountControl)
                filter = "(&(objectClass=computer)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))";
            }

            NamingEnumeration<javax.naming.directory.SearchResult> results = 
                ctx.search(baseDN, filter, controls);

            while (results.hasMore()) {
                javax.naming.directory.SearchResult sr = results.next();
                Attributes attrs = sr.getAttributes();
                result.count++;

                // Get hostname
                String hostname = getAttr(attrs, "dNSHostName");
                if (hostname == null || hostname.isEmpty()) {
                    hostname = getAttr(attrs, "cn");
                }
                if (hostname != null && !hostname.isEmpty()) {
                    result.hostnames.add(hostname.toLowerCase());
                }

                // Get additional DNS names
                Attribute additionalDns = attrs.get("msDS-AdditionalDnsHostName");
                if (additionalDns != null) {
                    for (int i = 0; i < additionalDns.size(); i++) {
                        String addHost = (String) additionalDns.get(i);
                        if (addHost != null) result.hostnames.add(addHost.toLowerCase());
                    }
                }

                // Get network addresses (may contain IPs)
                Attribute netAddr = attrs.get("networkAddress");
                if (netAddr != null) {
                    for (int i = 0; i < netAddr.size(); i++) {
                        String addr = (String) netAddr.get(i);
                        if (addr != null) {
                            String ip = extractIP(addr);
                            if (ip != null) result.ips.add(ip);
                        }
                    }
                }

                // Check SPNs for hostnames
                Attribute spn = attrs.get("servicePrincipalName");
                if (spn != null) {
                    for (int i = 0; i < spn.size(); i++) {
                        String spnVal = (String) spn.get(i);
                        if (spnVal != null && spnVal.contains("/")) {
                            String host = spnVal.split("/")[1];
                            if (host.contains(":")) host = host.split(":")[0];
                            if (!host.isEmpty()) result.hostnames.add(host.toLowerCase());
                        }
                    }
                }

                if (verbose && hostname != null) {
                    String os = getAttr(attrs, "operatingSystem");
                    System.out.println("    " + hostname + (os != null ? " (" + os + ")" : ""));
                }
            }
        } catch (Exception e) {
            System.out.println("    Warning: Computer search error - " + e.getMessage());
        }

        return result;
    }

    static SearchResult searchDNSRecords(DirContext ctx, String baseDN, boolean verbose) {
        SearchResult result = new SearchResult();

        // Try to find DNS zones in AD
        String[] dnsLocations = {
            "CN=MicrosoftDNS,DC=DomainDnsZones," + baseDN,
            "CN=MicrosoftDNS,DC=ForestDnsZones," + baseDN,
            "CN=MicrosoftDNS,CN=System," + baseDN
        };

        for (String dnsBase : dnsLocations) {
            try {
                SearchControls controls = new SearchControls();
                controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
                controls.setReturningAttributes(new String[]{"dnsRecord", "dc", "name"});

                NamingEnumeration<javax.naming.directory.SearchResult> results = 
                    ctx.search(dnsBase, "(objectClass=dnsNode)", controls);

                while (results.hasMore()) {
                    javax.naming.directory.SearchResult sr = results.next();
                    Attributes attrs = sr.getAttributes();

                    Attribute dnsRecord = attrs.get("dnsRecord");
                    if (dnsRecord != null) {
                        for (int i = 0; i < dnsRecord.size(); i++) {
                            byte[] record = (byte[]) dnsRecord.get(i);
                            String ip = extractIPFromDnsRecord(record);
                            if (ip != null) {
                                result.ips.add(ip);
                                if (verbose) {
                                    String name = getAttr(attrs, "name");
                                    if (name == null) name = getAttr(attrs, "dc");
                                    System.out.println("    DNS: " + (name != null ? name + " -> " : "") + ip);
                                }
                            }
                        }
                    }
                }
            } catch (NameNotFoundException e) {
                // DNS zone not found at this location, try next
            } catch (Exception e) {
                if (verbose) System.out.println("    DNS search error at " + dnsBase + ": " + e.getMessage());
            }
        }

        return result;
    }

    static SearchResult searchDHCP(DirContext ctx, String baseDN, boolean verbose) {
        SearchResult result = new SearchResult();

        try {
            // Search for DHCP server objects
            SearchControls controls = new SearchControls();
            controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            
            NamingEnumeration<javax.naming.directory.SearchResult> results = 
                ctx.search(baseDN, "(objectClass=dHCPClass)", controls);

            while (results.hasMore()) {
                javax.naming.directory.SearchResult sr = results.next();
                Attributes attrs = sr.getAttributes();
                
                // Extract any IP-related attributes
                NamingEnumeration<? extends Attribute> allAttrs = attrs.getAll();
                while (allAttrs.hasMore()) {
                    Attribute attr = allAttrs.next();
                    for (int i = 0; i < attr.size(); i++) {
                        Object val = attr.get(i);
                        if (val instanceof String) {
                            String ip = extractIP((String) val);
                            if (ip != null) result.ips.add(ip);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // DHCP info might not be accessible
        }

        return result;
    }

    static String extractIPFromDnsRecord(byte[] record) {
        // DNS A record format in AD
        // The IP is usually at offset 24 for A records (type 1)
        if (record == null || record.length < 28) return null;

        try {
            // Check record type (at offset 2, little-endian)
            int recordType = (record[2] & 0xFF) | ((record[3] & 0xFF) << 8);
            
            if (recordType == 1) { // A record
                // IP address at offset 24
                int ip1 = record[24] & 0xFF;
                int ip2 = record[25] & 0xFF;
                int ip3 = record[26] & 0xFF;
                int ip4 = record[27] & 0xFF;
                
                String ip = ip1 + "." + ip2 + "." + ip3 + "." + ip4;
                if (isValidIP(ip) && !ip.equals("0.0.0.0") && !ip.startsWith("127.")) {
                    return ip;
                }
            }
        } catch (Exception e) {
            // Invalid record format
        }
        return null;
    }

    static String extractIP(String text) {
        if (text == null) return null;
        
        Pattern pattern = Pattern.compile("(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            String ip = matcher.group(1);
            if (isValidIP(ip)) return ip;
        }
        return null;
    }

    static boolean isValidIP(String ip) {
        if (ip == null) return false;
        String[] parts = ip.split("\\.");
        if (parts.length != 4) return false;
        try {
            for (String part : parts) {
                int num = Integer.parseInt(part);
                if (num < 0 || num > 255) return false;
            }
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    static String getAttr(Attributes attrs, String name) {
        try {
            Attribute attr = attrs.get(name);
            if (attr != null) {
                Object val = attr.get();
                if (val != null) return val.toString();
            }
        } catch (Exception e) {}
        return null;
    }

    static String serverToBaseDN(String server) {
        // Convert server name to base DN
        // e.g., dc.example.com -> DC=example,DC=com
        String[] parts = server.split("\\.");
        StringBuilder dn = new StringBuilder();
        
        // Skip first part if it looks like a hostname (dc, ad, ldap, etc)
        int start = 0;
        if (parts.length > 2) {
            String first = parts[0].toLowerCase();
            if (first.equals("dc") || first.equals("ad") || first.equals("ldap") || 
                first.equals("pdc") || first.equals("bdc") || first.length() <= 3) {
                start = 1;
            }
        }
        
        for (int i = start; i < parts.length; i++) {
            if (dn.length() > 0) dn.append(",");
            dn.append("DC=").append(parts[i]);
        }
        return dn.toString();
    }

    static String detectDomainController() {
        String dc = null;
        
        // Method 1: Check environment variables
        String logonServer = System.getenv("LOGONSERVER");
        if (logonServer != null && !logonServer.isEmpty()) {
            dc = logonServer.replace("\\\\", "").replace("\\", "");
            if (!dc.isEmpty()) return dc;
        }

        // Method 2: Check USERDNSDOMAIN
        String dnsDomain = System.getenv("USERDNSDOMAIN");
        if (dnsDomain != null && !dnsDomain.isEmpty()) {
            // Try to resolve the domain to a DC
            try {
                java.net.InetAddress[] addrs = java.net.InetAddress.getAllByName(dnsDomain);
                if (addrs.length > 0) {
                    return dnsDomain;
                }
            } catch (Exception e) {}
        }

        // Method 3: Check USERDOMAIN and try common DC names
        String domain = System.getenv("USERDOMAIN");
        if (domain != null && !domain.isEmpty()) {
            String[] prefixes = {"dc", "ad", "dc1", "dc01", "pdc"};
            for (String prefix : prefixes) {
                String testDc = prefix + "." + domain;
                try {
                    java.net.InetAddress.getByName(testDc);
                    return testDc;
                } catch (Exception e) {}
            }
            // Try domain itself
            try {
                java.net.InetAddress.getByName(domain);
                return domain;
            } catch (Exception e) {}
        }

        // Method 4: Try to run nltest or nslookup (Windows)
        try {
            Process p = Runtime.getRuntime().exec("nltest /dsgetdc:");
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("DC:")) {
                    String[] parts = line.split("\\\\");
                    if (parts.length > 1) {
                        dc = parts[parts.length - 1].trim();
                        if (!dc.isEmpty()) return dc;
                    }
                }
            }
        } catch (Exception e) {}

        // Method 5: Try DNS SRV lookup for _ldap._tcp
        String dnsD = System.getenv("USERDNSDOMAIN");
        if (dnsD == null) dnsD = System.getenv("USERDOMAIN");
        if (dnsD != null) {
            try {
                Hashtable<String, String> env = new Hashtable<>();
                env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.dns.DnsContextFactory");
                DirContext dnsCtx = new InitialDirContext(env);
                Attributes attrs = dnsCtx.getAttributes("_ldap._tcp." + dnsD, new String[]{"SRV"});
                Attribute srv = attrs.get("SRV");
                if (srv != null && srv.size() > 0) {
                    String srvRecord = srv.get(0).toString();
                    String[] parts = srvRecord.split("\\s+");
                    if (parts.length >= 4) {
                        dc = parts[3];
                        if (dc.endsWith(".")) dc = dc.substring(0, dc.length() - 1);
                        return dc;
                    }
                }
            } catch (Exception e) {}
        }

        return null;
    }

    static String createJaasConfig() {
        // Create a temporary JAAS config for Windows integrated auth
        try {
            File tempFile = File.createTempFile("jaas", ".conf");
            tempFile.deleteOnExit();
            PrintWriter pw = new PrintWriter(tempFile);
            pw.println("com.sun.security.jgss.initiate {");
            pw.println("  com.sun.security.auth.module.Krb5LoginModule required");
            pw.println("  useTicketCache=true");
            pw.println("  doNotPrompt=true;");
            pw.println("};");
            pw.close();
            return tempFile.getAbsolutePath();
        } catch (Exception e) {
            return "";
        }
    }

    static void printUsage() {
        System.out.println("AD IP Extractor v1.2 - Extract all IPs from Active Directory");
        System.out.println("=============================================================");
        System.out.println("");
        System.out.println("Usage: java ADIPExtractor [options]");
        System.out.println("");
        System.out.println("Server (optional - auto-detected on domain PCs):");
        System.out.println("  -s <server>          LDAP server (DC hostname or IP)");
        System.out.println("");
        System.out.println("Authentication (choose one):");
        System.out.println("  -k, --integrated     Use current Windows login (Kerberos/NTLM)");
        System.out.println("  -u <user> -p <pass>  Use explicit credentials");
        System.out.println("  (none)               Anonymous bind (if allowed)");
        System.out.println("");
        System.out.println("Optional:");
        System.out.println("  -d <baseDN>          Base DN (auto-detected if not specified)");
        System.out.println("  -o <file>            Output file (default: ad_ips.txt)");
        System.out.println("  --include-disabled   Include disabled computer accounts");
        System.out.println("  -v                   Verbose output");
        System.out.println("");
        System.out.println("Examples:");
        System.out.println("  # Simplest - auto-detect everything, use Windows login");
        System.out.println("  java ADIPExtractor -k");
        System.out.println("");
        System.out.println("  # Specify DC manually");
        System.out.println("  java ADIPExtractor -s dc.example.com -k");
        System.out.println("");
        System.out.println("  # With explicit credentials");
        System.out.println("  java ADIPExtractor -s 192.168.1.10 -u admin@example.com -p Pass123");
        System.out.println("");
        System.out.println("Output:");
        System.out.println("  Creates two files:");
        System.out.println("    - ad_ips.txt           All discovered IPs (for NetScanner)");
        System.out.println("    - ad_ips_hostnames.txt All hostnames found");
        System.out.println("");
        System.out.println("Full workflow:");
        System.out.println("  java ADIPExtractor -k -o targets.txt");
        System.out.println("  java NetScanner -iL targets.txt -o scan_report.txt");
    }

    // Helper class for search results
    static class SearchResult {
        Set<String> ips = new TreeSet<>(new IPComparator());
        Set<String> hostnames = new TreeSet<>();
        int count = 0;
    }

    // IP address comparator for proper sorting
    static class IPComparator implements Comparator<String> {
        public int compare(String a, String b) {
            try {
                String[] pa = a.split("\\.");
                String[] pb = b.split("\\.");
                for (int i = 0; i < 4; i++) {
                    int cmp = Integer.compare(Integer.parseInt(pa[i]), Integer.parseInt(pb[i]));
                    if (cmp != 0) return cmp;
                }
            } catch (Exception e) {}
            return a.compareTo(b);
        }
    }
}
